function isAuthenticated(req, res, next) {
    if (req.session.userId) return next();
    req.flash("message", "Please log in first!");
    return res.redirect("/login");
}

module.exports = isAuthenticated;
