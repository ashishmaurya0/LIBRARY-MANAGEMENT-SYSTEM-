// Admin Users Management JavaScript
console.log('Admin Users JS loaded successfully!');

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', function () {
    console.log('DOM loaded, setting up modals...');

    initializeSuspendModal();
    initializeActivateModal();
    autoDismissAlerts();
});

// Initialize suspend modal functionality
function initializeSuspendModal() {
    const suspendModal = document.getElementById('suspendModal');

    if (suspendModal) {
        console.log('Suspend modal found, setting up event listener...');

        suspendModal.addEventListener('show.bs.modal', function (event) {
            // Button that triggered the modal
            const button = event.relatedTarget;

            if (button) {
                // Extract info from data-* attributes
                const userId = button.getAttribute('data-user-id');
                const userName = button.getAttribute('data-user-name');

                console.log('Suspend modal opening for user:', userId, userName);

                // Update the modal's content
                const userIdInput = document.getElementById('suspendUserId');
                const modalMessage = document.getElementById('suspendModalMessage');

                if (userIdInput && modalMessage) {
                    userIdInput.value = userId;
                    modalMessage.textContent = 'Are you sure you want to suspend ' + userName + '?';
                    console.log('Suspend modal content updated successfully');
                } else {
                    console.error('Suspend modal elements not found');
                }
            } else {
                console.error('Button not found in suspend modal event');
            }
        });

    } else {
        console.error('Suspend modal element not found');
    }
}

// Initialize activate modal functionality
function initializeActivateModal() {
    const activateModal = document.getElementById('activateModal');

    if (activateModal) {
        console.log('Activate modal found, setting up event listener...');

        activateModal.addEventListener('show.bs.modal', function (event) {
            // Button that triggered the modal
            const button = event.relatedTarget;

            if (button) {
                // Extract info from data-* attributes
                const userId = button.getAttribute('data-user-id');
                const userName = button.getAttribute('data-user-name');

                console.log('Activate modal opening for user:', userId, userName);

                // Update the modal's content
                const userIdInput = document.getElementById('activateUserId');
                const modalMessage = document.getElementById('activateModalMessage');

                if (userIdInput && modalMessage) {
                    userIdInput.value = userId;
                    modalMessage.textContent = 'Are you sure you want to activate ' + userName + '?';
                    console.log('Activate modal content updated successfully');
                } else {
                    console.error('Activate modal elements not found');
                }
            } else {
                console.error('Button not found in activate modal event');
            }
        });

    } else {
        console.error('Activate modal element not found');
    }
}

// Auto-dismiss alerts after 5 seconds
function autoDismissAlerts() {
    const alerts = document.querySelectorAll('.alert');
    console.log('Found alerts:', alerts.length);

    alerts.forEach(alert => {
        setTimeout(() => {
            if (alert && alert.classList.contains('show')) {
                try {
                    const bsAlert = new bootstrap.Alert(alert);
                    bsAlert.close();
                    console.log('Alert dismissed');
                } catch (error) {
                    console.error('Error dismissing alert:', error);
                }
            }
        }, 5000);
    });
}

// Make functions available globally if needed
window.adminUsers = {
    initializeSuspendModal,
    initializeActivateModal,
    autoDismissAlerts
};

console.log('Admin Users JS initialization complete');