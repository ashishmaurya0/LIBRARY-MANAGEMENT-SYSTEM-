// PDF Generator for Book Information - Optimized Version
document.addEventListener('DOMContentLoaded', function () {
    // Initialize jsPDF
    const { jsPDF } = window.jspdf;

    // PDF Download Button Event Listeners
    const pdfButtons = document.querySelectorAll('.pdf-download-btn');

    pdfButtons.forEach(button => {
        button.addEventListener('click', function () {
            generateBookPDF(this);
        });
    });

    function generateBookPDF(button) {
        // Get book data from data attributes
        const bookData = {
            id: button.getAttribute('data-book-id'),
            title: button.getAttribute('data-book-title'),
            author: button.getAttribute('data-book-author'),
            genre: button.getAttribute('data-book-genre'),
            isbn: button.getAttribute('data-book-isbn'),
            description: button.getAttribute('data-book-description'),
            borrowedDate: button.getAttribute('data-borrowed-date'),
            dueDate: button.getAttribute('data-due-date')
        };

        // Create new PDF document
        const doc = new jsPDF();

        // Set PDF properties
        doc.setProperties({
            title: `Book Details - ${bookData.title}`,
            subject: 'Book Information',
            author: 'BookStore Library',
            keywords: 'book, library, borrow, reading',
            creator: 'BookStore Management System'
        });

        // Add header
        doc.setFillColor(41, 128, 185);
        doc.rect(0, 0, 210, 25, 'F');

        // Header text
        doc.setTextColor(255, 255, 255);
        doc.setFontSize(16);
        doc.setFont('helvetica', 'bold');
        doc.text('BookStore Library', 105, 12, { align: 'center' });

        doc.setFontSize(10);
        doc.setFont('helvetica', 'normal');
        doc.text('Book Borrowing Receipt', 105, 18, { align: 'center' });

        // Reset text color
        doc.setTextColor(0, 0, 0);

        let yPosition = 35;

        // Book Information Table
        yPosition = createTable(doc, 'BOOK INFORMATION', [
            { field: 'Title', value: bookData.title },
            { field: 'Author', value: bookData.author },
            { field: 'Genre', value: bookData.genre },
            { field: 'ISBN', value: bookData.isbn }
        ], yPosition);

        yPosition += 10;

        // Borrowing Information Table
        yPosition = createTable(doc, 'BORROWING DETAILS', [
            { field: 'Borrowed Date', value: bookData.borrowedDate },
            { field: 'Due Date', value: bookData.dueDate },
            { field: 'Borrowing Period', value: '14 Days' },
            { field: 'Status', value: 'Currently Borrowed' }
        ], yPosition);

        yPosition += 10;

        // Description Section in Compact Box
        if (bookData.description && bookData.description !== 'No description available') {
            yPosition = createDescriptionBox(doc, bookData.description, yPosition);
            yPosition += 10;
        }

        // Compact Guidelines Section
        yPosition = createCompactGuidelines(doc, yPosition);

        // Footer
        const currentDate = new Date().toLocaleDateString();

        doc.setFillColor(41, 128, 185);
        doc.rect(0, 277, 210, 20, 'F');

        doc.setTextColor(255, 255, 255);
        doc.setFontSize(8);
        doc.text(`Generated on: ${currentDate}`, 20, 285);
        doc.text('BookStore Library System', 105, 285, { align: 'center' });
        doc.text('Page 1 of 1', 190, 285, { align: 'right' });

        // Save the PDF
        const fileName = `book_receipt_${bookData.title.replace(/[^a-zA-Z0-9]/g, '_')}.pdf`;
        doc.save(fileName);

        // Show success message
        showPDFSuccessMessage(bookData.title);
    }

    function createTable(doc, sectionTitle, rows, startY) {
        const tableTop = startY;
        const rowHeight = 8;
        const fieldColWidth = 50;
        const valueColWidth = 125;

        // Section header
        doc.setFontSize(12);
        doc.setFont('helvetica', 'bold');
        doc.setTextColor(41, 128, 185);
        doc.text(sectionTitle, 20, tableTop);

        let currentY = tableTop + 8;

        // Table header
        doc.setFillColor(240, 240, 240);
        doc.rect(20, currentY, fieldColWidth, rowHeight, 'F');
        doc.rect(70, currentY, valueColWidth, rowHeight, 'F');

        // Header borders
        doc.setDrawColor(150, 150, 150);
        doc.rect(20, currentY, fieldColWidth, rowHeight);
        doc.rect(70, currentY, valueColWidth, rowHeight);

        // Header text
        doc.setTextColor(0, 0, 0);
        doc.setFontSize(9);
        doc.setFont('helvetica', 'bold');
        doc.text('FIELD', 20 + fieldColWidth / 2, currentY + 5, { align: 'center' });
        doc.text('VALUE', 70 + valueColWidth / 2, currentY + 5, { align: 'center' });

        currentY += rowHeight;

        // Table rows
        rows.forEach((row, index) => {
            // Alternate row colors
            if (index % 2 === 0) {
                doc.setFillColor(255, 255, 255);
            } else {
                doc.setFillColor(250, 250, 250);
            }

            // Row background
            doc.rect(20, currentY, fieldColWidth, rowHeight, 'F');
            doc.rect(70, currentY, valueColWidth, rowHeight, 'F');

            // Row borders
            doc.setDrawColor(200, 200, 200);
            doc.rect(20, currentY, fieldColWidth, rowHeight);
            doc.rect(70, currentY, valueColWidth, rowHeight);

            // Field
            doc.setFont('helvetica', 'bold');
            doc.text(row.field, 25, currentY + 5);

            // Value
            doc.setFont('helvetica', 'normal');
            const valueLines = doc.splitTextToSize(String(row.value), valueColWidth - 10);
            doc.text(valueLines, 75, currentY + 5);

            currentY += rowHeight;

            // Adjust for multi-line values
            if (valueLines.length > 1) {
                currentY += (valueLines.length - 1) * 4;
            }
        });

        return currentY + 5;
    }

    function createDescriptionBox(doc, description, startY) {
        const boxTop = startY;

        // Section header
        doc.setFontSize(12);
        doc.setFont('helvetica', 'bold');
        doc.setTextColor(41, 128, 185);
        doc.text('BOOK DESCRIPTION', 20, boxTop);

        const contentTop = boxTop + 8;

        // Compact description box
        const descriptionLines = doc.splitTextToSize(description, 160);
        const boxHeight = Math.min(descriptionLines.length * 4 + 12, 40); // Limit height

        // Description box with border
        doc.setFillColor(255, 255, 255);
        doc.roundedRect(20, contentTop, 170, boxHeight, 3, 3, 'F');
        doc.setDrawColor(41, 128, 185);
        doc.setLineWidth(0.5);
        doc.roundedRect(20, contentTop, 170, boxHeight, 3, 3);

        // Description content
        doc.setTextColor(0, 0, 0);
        doc.setFontSize(9);
        doc.setFont('helvetica', 'normal');

        doc.text(descriptionLines, 25, contentTop + 8);

        return contentTop + boxHeight + 5;
    }

    function createCompactGuidelines(doc, startY) {
        const sectionTop = startY;

        // Section header
        doc.setFontSize(12);
        doc.setFont('helvetica', 'bold');
        doc.setTextColor(41, 128, 185);
        doc.text('IMPORTANT GUIDELINES', 20, sectionTop);

        let currentY = sectionTop + 8;

        // Compact guidelines box
        const boxHeight = 45;
        doc.setFillColor(255, 255, 255);
        doc.roundedRect(20, currentY, 170, boxHeight, 3, 3, 'F');
        doc.setDrawColor(150, 150, 150);
        doc.roundedRect(20, currentY, 170, boxHeight, 3, 3);

        // Guidelines content - compact points
        doc.setTextColor(0, 0, 0);
        doc.setFontSize(8);
        doc.setFont('helvetica', 'normal');

        const guidelines = [
            "• Return books on or before due date",
            "• Late returns: $1 per day penalty",
            "• Handle books with care - no markings",
            "• Report damage immediately",
            "• Lost books must be replaced",
            "• Renew online if available",
            "• Max 5 books per user"
        ];

        guidelines.forEach((guideline, index) => {
            doc.text(guideline, 25, currentY + 8 + (index * 5));
        });

        return currentY + boxHeight + 5;
    }

    function showPDFSuccessMessage(bookTitle) {
        // Create a temporary success alert
        const alertDiv = document.createElement('div');
        alertDiv.className = 'alert alert-success alert-dismissible fade show position-fixed top-0 start-50 translate-middle-x mt-3';
        alertDiv.style.zIndex = '9999';
        alertDiv.innerHTML = `
            <i class="fas fa-file-pdf me-2"></i>
            PDF receipt for "${bookTitle}" downloaded successfully!
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        `;

        document.body.appendChild(alertDiv);

        // Auto remove after 3 seconds
        setTimeout(() => {
            if (alertDiv.parentNode) {
                alertDiv.remove();
            }
        }, 3000);
    }
});