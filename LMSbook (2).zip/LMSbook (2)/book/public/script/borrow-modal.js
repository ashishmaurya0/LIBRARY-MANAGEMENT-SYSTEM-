// borrow-modal.js - Modal functionality for borrow and return actions
document.addEventListener('DOMContentLoaded', function () {
    // Borrow Book Modal
    const borrowButtons = document.querySelectorAll('.btn-borrow');
    const borrowModal = new bootstrap.Modal(document.getElementById('borrowConfirmModal'));
    const borrowConfirmBtn = document.getElementById('confirmBorrow');
    let currentBorrowForm = null;

    borrowButtons.forEach(button => {
        button.addEventListener('click', function (e) {
            e.preventDefault();

            const form = this.closest('form');
            const bookTitle = this.closest('.book-card').querySelector('.book-title').textContent;
            const bookAuthor = this.closest('.book-card').querySelector('.book-author').textContent;

            // Set modal content
            document.getElementById('borrowBookTitle').textContent = bookTitle;
            document.getElementById('borrowBookAuthor').textContent = bookAuthor;

            // Store current form for confirmation
            currentBorrowForm = form;

            // Show modal
            borrowModal.show();
        });
    });

    // Confirm borrow action
    borrowConfirmBtn.addEventListener('click', function () {
        if (currentBorrowForm) {
            currentBorrowForm.submit();
        }
    });

    // Return Book Modal
    const returnButtons = document.querySelectorAll('.btn-return');
    const returnModal = new bootstrap.Modal(document.getElementById('returnConfirmModal'));
    const returnConfirmBtn = document.getElementById('confirmReturn');
    let currentReturnForm = null;

    returnButtons.forEach(button => {
        button.addEventListener('click', function (e) {
            e.preventDefault();

            const form = this.closest('form');
            const bookTitle = this.closest('tr').querySelector('td:nth-child(2)').textContent.trim();

            // Set modal content
            document.getElementById('returnBookTitle').textContent = bookTitle;

            // Store current form for confirmation
            currentReturnForm = form;

            // Show modal
            returnModal.show();
        });
    });

    // Confirm return action
    returnConfirmBtn.addEventListener('click', function () {
        if (currentReturnForm) {
            currentReturnForm.submit();
        }
    });

    // Reset forms when modal is hidden
    document.getElementById('borrowConfirmModal').addEventListener('hidden.bs.modal', function () {
        currentBorrowForm = null;
    });

    document.getElementById('returnConfirmModal').addEventListener('hidden.bs.modal', function () {
        currentReturnForm = null;
    });
});