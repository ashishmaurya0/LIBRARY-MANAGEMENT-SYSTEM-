// Delete Modal Functionality
document.addEventListener('DOMContentLoaded', function () {
    initDeleteModal();
    autoDismissAlerts();
});

function initDeleteModal() {
    const deleteForm = document.getElementById('deleteBookForm');
    const modal = document.getElementById('deleteBookModal');
    const backdrop = document.getElementById('modalBackdrop');
    const cancelButton = document.getElementById('cancelDelete');
    const confirmButton = document.getElementById('confirmDelete');
    const closeButtons = document.querySelectorAll('.modal-close-btn');
    const bookSelect = document.getElementById('bookId');

    // Intercept form submission to show modal instead
    if (deleteForm) {
        deleteForm.addEventListener('submit', function (e) {
            e.preventDefault();

            const selectedBookId = bookSelect.value;
            if (!selectedBookId) {
                alert('Please select a book to delete.');
                return;
            }

            showDeleteModal(selectedBookId);
        });
    }

    // Close modal events
    if (cancelButton) {
        cancelButton.addEventListener('click', hideModal);
    }

    if (closeButtons) {
        closeButtons.forEach(button => {
            button.addEventListener('click', hideModal);
        });
    }

    // Confirm delete action
    if (confirmButton) {
        confirmButton.addEventListener('click', function () {
            const bookId = this.getAttribute('data-book-id');
            deleteBook(bookId);
        });
    }

    // Close modal when clicking outside
    if (backdrop) {
        backdrop.addEventListener('click', hideModal);
    }

    // Close modal with Escape key
    document.addEventListener('keydown', function (e) {
        if (e.key === 'Escape' && modal && modal.classList.contains('show')) {
            hideModal();
        }
    });
}

function showDeleteModal(bookId) {
    const modal = document.getElementById('deleteBookModal');
    const backdrop = document.getElementById('modalBackdrop');
    const confirmButton = document.getElementById('confirmDelete');

    if (modal && backdrop && confirmButton) {
        // Get scrollbar width and apply compensation
        const scrollbarWidth = window.innerWidth - document.documentElement.clientWidth;

        if (scrollbarWidth > 0) {
            document.body.style.overflow = 'hidden';
            document.body.style.paddingRight = scrollbarWidth + 'px';

            // Apply to navbar
            const navbar = document.querySelector('nav, .navbar, header');
            if (navbar) {
                const currentPadding = window.getComputedStyle(navbar).paddingRight;
                const currentPaddingNum = parseFloat(currentPadding) || 0;
                navbar.style.paddingRight = (currentPaddingNum + scrollbarWidth) + 'px';
            }
        } else {
            document.body.style.overflow = 'hidden';
        }

        // Show modal and backdrop
        modal.style.display = 'block';
        backdrop.style.display = 'block';

        setTimeout(() => {
            modal.classList.add('show');
            backdrop.classList.add('show');
        }, 10);

        confirmButton.setAttribute('data-book-id', bookId);
    }
}

function hideModal() {
    const modal = document.getElementById('deleteBookModal');
    const backdrop = document.getElementById('modalBackdrop');

    if (modal && backdrop) {
        modal.classList.remove('show');
        backdrop.classList.remove('show');

        setTimeout(() => {
            modal.style.display = 'none';
            backdrop.style.display = 'none';

            // Restore all styles
            document.body.style.overflow = '';
            document.body.style.paddingRight = '';

            // Restore navbar padding
            const navbar = document.querySelector('nav, .navbar, header');
            if (navbar) {
                navbar.style.paddingRight = '';
            }
        }, 150);
    }
}

function deleteBook(bookId) {
    const confirmButton = document.getElementById('confirmDelete');



    // Submit the original form directly
    const deleteForm = document.getElementById('deleteBookForm');
    if (deleteForm) {
        deleteForm.submit();
    }
}

// Auto-dismiss alerts after 5 seconds
function autoDismissAlerts() {
    const alerts = document.querySelectorAll('.alert');

    alerts.forEach(alert => {
        setTimeout(() => {
            if (alert && alert.classList.contains('show')) {
                try {
                    const bsAlert = new bootstrap.Alert(alert);
                    bsAlert.close();
                } catch (error) {
                    alert.style.display = 'none';
                }
            }
        }, 5000);
    });
}