# Book Management System

A full-stack web application for managing an online book store, built with Node.js, Express, MongoDB, and EJS. This system allows users to browse, borrow, and manage books, while providing administrators with tools to oversee the inventory and user activities.

## Features

- **User Authentication**: Secure login and registration for users.
- **Book Management**: Add, edit, remove, and search books by title, author, genre, or ISBN.
- **Borrowing System**: Users can borrow books with due dates and borrowing history tracking.
- **Admin Dashboard**: Administrators can manage users, books, and view analytics.
- **Session Management**: Persistent sessions with flash messages for user feedback.
- **Responsive UI**: Built with Bootstrap for a mobile-friendly interface.
- **Database Integration**: Uses MongoDB for data storage and MySQL2 for additional database support.

## Installation

1. **Clone the repository**:
   ```bash
   git clone <repository-url>
   cd book
   ```

2. **Install dependencies**:
   ```bash
   npm install
   ```

3. **Set up environment variables**:
   Create a `.env` file in the root directory with the following:
   ```
   MONGO_URI=mongodb://127.0.0.1:27017/bookDB
   SESSION_SECRET=your-secret-key
   ```

4. **Start MongoDB**:
   Ensure MongoDB is running on your system.

5. **Run the application**:
   ```bash
   npm start
   ```
   The server will start at `http://localhost:8080`.

## Usage

- **Home Page**: Browse the book store and learn about features.
- **Authentication**: Register or log in to access user-specific features.
- **Book Operations**: Search and borrow books if logged in.
- **Admin Panel**: Access `/admin` routes for administrative tasks (requires admin login).

## Technologies Used

- **Backend**: Node.js, Express.js
- **Database**: MongoDB (with Mongoose), MySQL2
- **Frontend**: EJS, Bootstrap, Font Awesome
- **Authentication**: Express-Session, Connect-Flash
- **Other**: Dotenv for environment variables

## Project Structure

```
book/
├── app.js                 # Main application file
├── package.json           # Dependencies and scripts
├── config/
│   └── db.js              # Database connection
├── models/
│   ├── userModel.js       # User schema
│   ├── bookModel.js       # Book schema
│   └── adminModel.js      # Admin schema
├── routes/
│   ├── index.js           # Main routes aggregator
│   ├── auth/              # Authentication routes
│   ├── admin/             # Admin routes
│   ├── books/             # Book-related routes
│   └── general/           # General routes
├── views/
│   ├── index.ejs          # Home page
│   ├── profile.ejs        # User profile
│   └── partials/          # Reusable EJS components
├── public/                # Static assets (CSS, JS, images)
└── middleware/            # Custom middleware
```

## Contributing

1. Fork the repository.
2. Create a new branch for your feature.
3. Commit your changes.
4. Push to the branch.
5. Open a pull request.

## License

This project is licensed under the ISC License.
