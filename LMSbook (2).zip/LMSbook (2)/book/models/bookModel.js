const mongoose = require("mongoose");

const bookSchema = new mongoose.Schema({
    user_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        required: true
    },
    title: {
        type: String,
        required: true
    },
    author: {
        type: String,
        required: true
    },
    genre: {
        type: String,
        required: true
    },
    isbn: {
        type: String,
        required: true,
        unique: true
    },
    description: {
        type: String,
        default: ""
    },
    
    // CURRENT borrowing info (for active borrows)
    isAvailable: {
        type: Boolean,
        default: true
    },
    borrowedBy: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        default: null
    },
    borrowedDate: {
        type: Date,
        default: null
    },
    dueDate: {
        type: Date,
        default: null
    },
    
    // NEW: Borrowing history (for all past borrows)
    borrowHistory: [{
        user: {
            type: mongoose.Schema.Types.ObjectId,
            ref: 'User',
            required: true
        },
        borrowedDate: {
            type: Date,
            required: true
        },
        dueDate: {
            type: Date,
            required: true
        },
        returnDate: {
            type: Date,
            default: null
        },
        status: {
            type: String,
            enum: ['active', 'returned'],
            default: 'active'
        }
    }]
}, {
    timestamps: true
});

module.exports = mongoose.model("Book", bookSchema);