const express = require("express");
const router = express.Router();
const isAuthenticated = require("../../middleware/authMiddleware");

router.get("/", (req, res) => {
    res.render("index", { 
        message: req.flash("message"), 
        success: req.flash("success"), 
        session: req.session 
    });
});

router.get("/profile", isAuthenticated, (req, res) => {
    res.render("profile");
});

module.exports = router;