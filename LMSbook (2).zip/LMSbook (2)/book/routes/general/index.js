const express = require("express");
const router = express.Router();

const indexRoutes = require("./indexRoutes");

router.use("/", indexRoutes);

module.exports = router;