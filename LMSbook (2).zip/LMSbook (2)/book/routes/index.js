const express = require("express");
const router = express.Router();

// Import route modules
const authRoutes = require("./auth");
const adminRoutes = require("./admin");
const bookRoutes = require("./books");
const generalRoutes = require("./general");

// Use the route modules
router.use("/", authRoutes);
router.use("/admin", adminRoutes);
router.use("/", bookRoutes);
router.use("/", generalRoutes);

module.exports = router;