const express = require("express");
const router = express.Router();
const isAuthenticated = require("../../middleware/authMiddleware");

// Regular user dashboard
router.get("/dashboard", isAuthenticated, (req, res) => {
    res.render("dashboard", {
        message: req.flash("message"),
        success: req.flash("success"),
        user: {
            name: req.session.userName,
            email: req.session.userEmail,
            isAdmin: false,
            userType: req.session.userType
        }
    });
});

module.exports = router;