const express = require("express");
const router = express.Router();
const Book = require("../../models/bookModel");
const isAuthenticated = require("../../middleware/authMiddleware");

// -------------------- UPDATE BOOK --------------------
router.get("/updateBook", isAuthenticated, async (req, res) => {
    try {
        const books = await Book.find({ user_id: req.session.userId });
        res.render("books/update", {
            books,
            book: null,
            viewMode: null,
            message: req.flash("message"),
            success: req.flash("success")
        });
    } catch (err) {
        console.error(err);
        req.flash("message", "Error loading update page!");
        res.redirect("/addBook");
    }
});

router.get("/bookDetails", isAuthenticated, async (req, res) => {
    try {
        const { bookId } = req.query;
        const book = await Book.findOne({ _id: bookId, user_id: req.session.userId });
        const books = await Book.find({ user_id: req.session.userId });

        if (!book) {
            req.flash("message", "Book not found!");
            return res.redirect("/updateBook");
        }

        res.render("books/update", {
            books,
            book,
            viewMode: "form",
            message: req.flash("message"),
            success: req.flash("success")
        });
    } catch (err) {
        console.error(err);
        req.flash("message", "Error fetching book details!");
        res.redirect("/updateBook");
    }
});

router.get("/showData", isAuthenticated, async (req, res) => {
    try {
        const { bookId } = req.query;
        const book = await Book.findOne({ _id: bookId, user_id: req.session.userId });
        const books = await Book.find({ user_id: req.session.userId });

        if (!book) {
            req.flash("message", "Book not found!");
            return res.redirect("/updateBook");
        }

        res.render("books/update", {
            books,
            book,
            viewMode: "table",
            message: req.flash("message"),
            success: req.flash("success")
        });
    } catch (err) {
        console.error(err);
        req.flash("message", "Error fetching book data!");
        res.redirect("/updateBook");
    }
});

router.post("/updateBook", isAuthenticated, async (req, res) => {
    try {
        const { bookId, title, author, genre, isbn, description } = req.body;
        
        const existingBook = await Book.findOne({ 
            isbn: isbn, 
            _id: { $ne: bookId }
        });
        
        if (existingBook) {
            req.flash("message", "ISBN already exists! Please use a different ISBN number.");
            return res.redirect("/updateBook");
        }

        await Book.findOneAndUpdate(
            { _id: bookId, user_id: req.session.userId },
            { title, author, genre, isbn, description }
        );
        req.flash("success", "Book updated successfully!");
    } catch (err) {
        console.error(err);
        if (err.code === 11000) {
            req.flash("message", "ISBN already exists! Please use a different ISBN number.");
        } else {
            req.flash("message", "Error updating book!");
        }
    }
    res.redirect("/updateBook");
});

module.exports = router;