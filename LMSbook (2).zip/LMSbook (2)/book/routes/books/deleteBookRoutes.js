const express = require("express");
const router = express.Router();
const Book = require("../../models/bookModel");
const isAuthenticated = require("../../middleware/authMiddleware");

// -------------------- DELETE BOOK --------------------
router.get("/deleteBook", isAuthenticated, async (req, res) => {
    try {
        const books = await Book.find({ user_id: req.session.userId });
        res.render("books/deletebook", {
            books,
            message: req.flash("message"),
            success: req.flash("success")
        });
    } catch (err) {
        console.error(err);
        req.flash("message", "Error loading delete page!");
        res.redirect("/admin/dashboard");
    }
});

router.post("/deleteBook", isAuthenticated, async (req, res) => {
    try {
        const { bookId } = req.body;
        await Book.deleteOne({ _id: bookId, user_id: req.session.userId });
        req.flash("success", "Book deleted successfully!");
    } catch (err) {
        console.error(err);
        req.flash("message", "Error deleting book!");
    }
    res.redirect("/deleteBook");
});

module.exports = router;