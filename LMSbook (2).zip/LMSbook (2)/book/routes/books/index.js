const express = require("express");
const router = express.Router();

const bookRoutes = require("./bookRoutes");
const addBookRoutes = require("./addBookRoutes");
const deleteBookRoutes = require("./deleteBookRoutes");
const updateBookRoutes = require("./updateBookRoutes");
const borrowReturnRoutes = require("./borrowReturnRoutes"); // Add this line

router.use("/", bookRoutes);
router.use("/", addBookRoutes);
router.use("/", deleteBookRoutes);
router.use("/", updateBookRoutes);
router.use("/", borrowReturnRoutes); // Add this line

module.exports = router;