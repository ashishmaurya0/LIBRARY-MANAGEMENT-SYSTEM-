const express = require("express");
const router = express.Router();
const Book = require("../../models/bookModel");
const isAuthenticated = require("../../middleware/authMiddleware");

// -------------------- ADD BOOK --------------------
router.get("/addBook", isAuthenticated, async (req, res) => {
    const books = await Book.find({ user_id: req.session.userId });
    res.render("books/addbook", {
        books,
        message: req.flash("message"),
        success: req.flash("success")
    });
});

router.post("/addBook", isAuthenticated, async (req, res) => {
    try {
        const { title, author, genre, isbn, desc } = req.body;
        
        const existingBook = await Book.findOne({ isbn: isbn });
        if (existingBook) {
            req.flash("message", "ISBN already exists! Please use a different ISBN number.");
            return res.redirect("/addBook");
        }

        const book = new Book({
            user_id: req.session.userId,
            title,
            author,
            genre,
            isbn,
            description: desc
        });
        await book.save();
        req.flash("success", "Book added successfully!");
    } catch (err) {
        console.error(err);
        if (err.code === 11000) {
            req.flash("message", "ISBN already exists! Please use a different ISBN number.");
        } else {
            req.flash("message", "Error adding book!");
        }
    }
    res.redirect("/addBook");
});

module.exports = router;