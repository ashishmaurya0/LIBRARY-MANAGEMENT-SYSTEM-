const express = require("express");
const router = express.Router();
const Book = require("../../models/bookModel");
const isAuthenticated = require("../../middleware/authMiddleware");

// -------------------- BORROW BOOK --------------------
router.get("/borrow-book", isAuthenticated, async (req, res) => {
    try {
        // Get ALL books from other users
        const allBooks = await Book.find({ 
            user_id: { $ne: req.session.userId } // Exclude user's own books
        }).populate('user_id', 'name email');

        res.render("borrow/borrow-book", {
            allBooks: allBooks || [],
            message: req.flash("message"),
            success: req.flash("success")
        });
    } catch (err) {
        console.error(err);
        req.flash("message", "Error loading books");
        res.redirect("/dashboard");
    }
});

router.post("/borrow-book", isAuthenticated, async (req, res) => {
    try {
        const { bookId } = req.body;
        
        const book = await Book.findById(bookId);
        
        if (!book) {
            req.flash("message", "Book not found!");
            return res.redirect("/borrow-book");
        }

        // Check if book is already borrowed by someone
        if (!book.isAvailable) {
            req.flash("message", "Book is already borrowed by someone else!");
            return res.redirect("/borrow-book");
        }

        // User cannot borrow their own book
        if (book.user_id.toString() === req.session.userId.toString()) {
            req.flash("message", "You cannot borrow your own book!");
            return res.redirect("/borrow-book");
        }

        // Calculate due date (14 days from now)
        const dueDate = new Date();
        dueDate.setDate(dueDate.getDate() + 14);

        // Update CURRENT borrowing info
        book.isAvailable = false;
        book.borrowedBy = req.session.userId;
        book.borrowedDate = new Date();
        book.dueDate = dueDate;
        
        // ADD to borrow history
        book.borrowHistory.push({
            user: req.session.userId,
            borrowedDate: new Date(),
            dueDate: dueDate,
            status: 'active'
        });
        
        await book.save();
        
        req.flash("success", `Book "${book.title}" borrowed successfully! Due date: ${dueDate.toDateString()}`);
    } catch (err) {
        console.error(err);
        req.flash("message", "Error borrowing book");
    }
    res.redirect("/borrow-book");
});
router.post("/return-book", isAuthenticated, async (req, res) => {
    try {
        const { bookId } = req.body;
        
        const book = await Book.findById(bookId);
        
        if (!book) {
            req.flash("message", "Book not found!");
            return res.redirect("/borrow-book");
        }

        // Check if the user actually borrowed this book
        if (!book.borrowedBy || book.borrowedBy.toString() !== req.session.userId.toString()) {
            req.flash("message", "You cannot return a book you didn't borrow!");
            return res.redirect("/borrow-book");
        }

        // Update CURRENT borrowing info (reset for next user)
        book.isAvailable = true;
        book.borrowedBy = null;
        book.borrowedDate = null;
        book.dueDate = null;
        
        // UPDATE borrow history - mark as returned
        const currentBorrow = book.borrowHistory.find(record => 
            record.user.toString() === req.session.userId.toString() && 
            record.status === 'active'
        );
        
        if (currentBorrow) {
            currentBorrow.returnDate = new Date();
            currentBorrow.status = 'returned';
        }
        
        await book.save();
        
        req.flash("success", `Book "${book.title}" returned successfully!`);
    } catch (err) {
        console.error(err);
        req.flash("message", "Error returning book");
    }
    res.redirect("/borrow-book");
});
module.exports = router;