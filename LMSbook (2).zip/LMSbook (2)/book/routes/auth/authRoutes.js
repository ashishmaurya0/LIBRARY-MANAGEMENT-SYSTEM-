const express = require("express");
const router = express.Router();
const User = require("../../models/userModel");
const Admin = require("../../models/adminModel");

// -------------------- SIGNUP ROUTES --------------------
router.get("/signup", (req, res) => res.render("auth/signup", {
    message: req.flash("message"),
    success: req.flash("success")
}));

router.post("/signup", async (req, res) => {
    try {
        const { name, email, password, confirmPassword } = req.body;

        if (!name || !email || !password || !confirmPassword) {
            req.flash("message", "All fields required");
            return res.redirect("/signup");
        }

        // Email validation
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(email)) {
            req.flash("message", "Please enter a valid email address");
            return res.redirect("/signup");
        }

        // Name validation (at least 2 characters)
        if (name.trim().length < 2) {
            req.flash("message", "Name must be at least 2 characters long");
            return res.redirect("/signup");
        }

        // Password validation
        if (password.length < 6) {
            req.flash("message", "Password must be at least 6 characters long");
            return res.redirect("/signup");
        }

        if (password !== confirmPassword) {
            req.flash("message", "Passwords do not match");
            return res.redirect("/signup");
        }

        const existing = await User.findOne({ email });
        if (existing) {
            req.flash("message", "Email already exists");
            return res.redirect("/signup");
        }

        const newUser = new User({ name, email, password });
        await newUser.save();
        req.flash("success", "Signup successful! Please log in.");
        res.redirect("/login");
    } catch (err) {
        console.error(err);
        req.flash("message", "Error during signup");
        res.redirect("/signup");
    }
});

// -------------------- LOGIN ROUTES --------------------
router.get("/login", (req, res) => res.render("auth/login", {
    message: req.flash("message"),
    success: req.flash("success")
}));

router.post("/login", async (req, res) => {
    try {
        const { email, password, userType } = req.body;

        if (!userType) {
            req.flash("message", "Please select login type");
            return res.redirect("/login");
        }

        if (userType === "admin") {
            const admin = await Admin.findOne({ email });
            if (!admin) {
                req.flash("message", "Admin account not found");
                return res.redirect("/login");
            }

            if (admin.password !== password) {
                req.flash("message", "Invalid admin password");
                return res.redirect("/login");
            }

            req.session.userId = admin._id;
            req.session.isAdmin = true;
            req.session.userEmail = admin.email;
            req.session.userType = "admin";
            req.flash("success", "Admin login successful!");
            return res.redirect("/admin/dashboard");

        } else if (userType === "user") {
            const user = await User.findOne({ email });
            if (!user) {
                req.flash("message", "User account not found");
                return res.redirect("/login");
            }

            // ✅ ADD THIS: Check if user is suspended
            if (user.status === 'suspended') {
                req.flash("message", "Your account has been suspended. Please contact administrator.");
                return res.redirect("/login");
            }

            if (user.password !== password) {
                req.flash("message", "Invalid user password");
                return res.redirect("/login");
            }

            // Update login tracking for users
            user.lastLogin = new Date();
            user.loginCount = (user.loginCount || 0) + 1;
            await user.save();

            req.session.userId = user._id;
            req.session.isAdmin = false;
            req.session.userName = user.name;
            req.session.userEmail = user.email;
            req.session.userType = "user";
            req.flash("success", "Login successful!");
            return res.redirect("/");

        } else {
            req.flash("message", "Invalid login type");
            return res.redirect("/login");
        }

    } catch (err) {
        console.error(err);
        req.flash("message", "Error during login");
        res.redirect("/login");
    }
});

// -------------------- LOGOUT ROUTE --------------------
router.get("/logout", (req, res) => {
    req.session.destroy(err => {
        if (err) console.error("Logout error:", err);
        res.redirect("/login");
    });
});

module.exports = router;