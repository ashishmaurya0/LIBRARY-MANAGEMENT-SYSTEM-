const express = require("express");
const router = express.Router();
const mongoose = require('mongoose');
const User = require("../../models/userModel");
const Book = require("../../models/bookModel"); 

// Admin middleware
const requireAdmin = (req, res, next) => {
    if (!req.session.userId || !req.session.isAdmin) {
        req.flash("message", "Access denied. Admin login required.");
        return res.redirect("/login");
    }
    next();
};

// -------------------- MANAGE USERS --------------------
router.get("/users", requireAdmin, async (req, res) => {
    try {
        const users = await User.find().select('name email status lastLogin loginCount createdAt').sort({ createdAt: -1 });
        const totalUsers = await User.countDocuments();
        const activeUsers = await User.countDocuments({ status: 'active' });
        const suspendedUsers = await User.countDocuments({ status: 'suspended' });

        res.render("admin/users", {
            users: users || [],
            totalUsers: totalUsers || 0,
            activeUsers: activeUsers || 0,
            suspendedUsers: suspendedUsers || 0,
            message: req.flash("message"),
            success: req.flash("success")
        });
    } catch (error) {
        console.error('Error loading users:', error);
        req.flash("message", "Error loading users data");
        res.redirect("/admin/dashboard");
    }
});

// -------------------- SUSPEND USER --------------------
router.post("/users/suspend", requireAdmin, async (req, res) => {
    try {
        const { userId } = req.body;
        
        if (!mongoose.Types.ObjectId.isValid(userId)) {
            req.flash("message", "Invalid user ID format!");
            return res.redirect("/admin/users");
        }
        
        if (userId === req.session.userId.toString()) {
            req.flash("message", "You cannot suspend your own account!");
            return res.redirect("/admin/users");
        }

        const result = await User.findByIdAndUpdate(userId, { status: 'suspended' });
        
        if (!result) {
            req.flash("message", "User not found!");
            return res.redirect("/admin/users");
        }
        
        req.flash("success", "User suspended successfully!");
        
    } catch (error) {
        console.error('Error suspending user:', error);
        req.flash("message", "Error suspending user");
    }
    res.redirect("/admin/users");
});

// -------------------- ACTIVATE USER --------------------
router.post("/users/activate", requireAdmin, async (req, res) => {
    try {
        const { userId } = req.body;
        
        if (!mongoose.Types.ObjectId.isValid(userId)) {
            req.flash("message", "Invalid user ID format!");
            return res.redirect("/admin/users");
        }

        const result = await User.findByIdAndUpdate(userId, { status: 'active' });
        
        if (!result) {
            req.flash("message", "User not found!");
            return res.redirect("/admin/users");
        }
        
        req.flash("success", "User activated successfully!");
        
    } catch (error) {
        console.error('Error activating user:', error);
        req.flash("message", "Error activating user");
    }
    res.redirect("/admin/users");
});

// -------------------- USER DETAILS --------------------
router.get("/users/:id", requireAdmin, async (req, res) => {
    try {
        const userId = req.params.id;
        
        if (!mongoose.Types.ObjectId.isValid(userId)) {
            req.flash("message", "Invalid user ID format!");
            return res.redirect("/admin/users");
        }

        const user = await User.findById(userId);
        if (!user) {
            req.flash("message", "User not found!");
            return res.redirect("/admin/users");
        }

        // FIX: Fetch books where this user has borrowing history
        const booksWithUserHistory = await Book.find({
            'borrowHistory.user': userId
        }).populate('borrowHistory.user', 'name');

        // Extract all borrowing records for this user
        const orders = [];
        booksWithUserHistory.forEach(book => {
            book.borrowHistory.forEach(record => {
                if (record.user._id.toString() === userId.toString()) {
                    orders.push({
                        bookTitle: book.title,
                        bookAuthor: book.author,
                        orderDate: record.borrowedDate,
                        dueDate: record.dueDate,
                        returnDate: record.returnDate,
                        status: record.status === 'active' ? 'borrowed' : 'returned'
                    });
                }
            });
        });

        // Sort by borrowed date (newest first)
        orders.sort((a, b) => new Date(b.orderDate) - new Date(a.orderDate));

        res.render("admin/user-details", {
            user: user,
            orders: orders || [],
            message: req.flash("message"),
            success: req.flash("success")
        });
    } catch (error) {
        console.error('Error loading user details:', error);
        req.flash("message", "Error loading user details");
        res.redirect("/admin/users");
    }
});module.exports = router;