const express = require("express");
const router = express.Router();

const adminRoutes = require("./adminRoutes");
const userManagementRoutes = require("./userManagementRoutes");

router.use("/", adminRoutes);
router.use("/", userManagementRoutes);

module.exports = router;