const express = require("express");
const router = express.Router();
const Book = require("../../models/bookModel");
const User = require("../../models/userModel");

// Admin middleware
const requireAdmin = (req, res, next) => {
    if (!req.session.userId || !req.session.isAdmin) {
        req.flash("message", "Access denied. Admin login required.");
        return res.redirect("/login");
    }
    next();
};

// -------------------- ADMIN USERS LIST --------------------
router.get("/admin/users", requireAdmin, async (req, res) => {
    try {
        const users = await User.find().sort({ createdAt: -1 });
        
        res.render("admin/users", {
            users: users || [],
            message: req.flash("message"),
            success: req.flash("success")
        });
    } catch (error) {
        console.error('Users list error:', error);
        req.flash("message", "Error loading users");
        res.redirect("/admin/dashboard");
    }
});

// -------------------- ADMIN USER DETAILS --------------------
router.get("/admin/users/:id", requireAdmin, async (req, res) => {
    try {
        const userId = req.params.id;
        
        // Fetch user details
        const user = await User.findById(userId);
        if (!user) {
            req.flash('message', 'User not found');
            return res.redirect('/admin/users');
        }

        // Fetch ALL books that this user has EVER borrowed (both current and returned)
        const borrowedBooks = await Book.find({
            $or: [
                { borrowedBy: userId }, // Currently borrowed books
                { returnDate: { $ne: null } } // Previously returned books
            ]
        }).sort({ borrowedDate: -1 });

        // Transform the data to match what your EJS template expects
        const orders = borrowedBooks.map(book => ({
            bookTitle: book.title,
            bookAuthor: book.author,
            orderDate: book.borrowedDate, // When the book was borrowed
            returnDate: book.returnDate, // When the book was returned (if returned)
            status: book.isAvailable ? 'returned' : 'borrowed' // Determine status
        }));

        console.log('Found borrowed books:', borrowedBooks.length); // Debug
        
        res.render('admin/user-details', {
            user: user,
            orders: orders, // This will show in your table
            message: req.flash('message'),
            success: req.flash('success')
        });

    } catch (error) {
        console.error('Error fetching user details:', error);
        req.flash('message', 'Error loading user details');
        res.redirect('/admin/users');
    }
});

// -------------------- ADMIN DASHBOARD --------------------
router.get("/dashboard", requireAdmin, async (req, res) => {
    try {
        const totalBooks = await Book.countDocuments();
        const totalUsers = await User.countDocuments();
        const books = await Book.find().sort({ _id: 1 });

        res.render("admin/dashboard", { 
            message: req.flash("message"), 
            success: req.flash("success"),
            user: {
                email: req.session.userEmail,
                isAdmin: true,
                userType: req.session.userType
            },
            totalBooks: totalBooks || 0,
            totalUsers: totalUsers || 0,
            books: books || []
        });
    } catch (error) {
        console.error('Dashboard error:', error);
        res.render("admin/dashboard", {
            message: "Error loading dashboard data",
            success: null,
            user: {
                email: req.session.userEmail,
                isAdmin: true,
                userType: req.session.userType
            },
            totalBooks: 0,
            totalUsers: 0,
            books: []
        });
    }
});

module.exports = router;